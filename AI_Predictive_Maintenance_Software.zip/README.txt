AI Predictive Maintenance — College Project

Run:
1. Install Python 3.10+.
2. In this folder: pip install -r requirements.txt
3. Start: streamlit run app.py
4. Open the local Streamlit address.

The app predicts Healthy, Warning, or Fault from temperature, vibration, current and RPM.
The included training data is synthetic demonstration data, not an industrially validated model.
Next step: connect Arduino/ESP32 sensors and collect real labeled data.
